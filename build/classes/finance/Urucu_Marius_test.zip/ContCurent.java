package finance;


public class ContCurent extends Cont {
    
    public ContCurent(){
        super();
    }
    
    public ContCurent(String iBan, String beneficiar, float sold, String moneda){
        super(iBan, beneficiar, sold, moneda);
    }
    
    
}
